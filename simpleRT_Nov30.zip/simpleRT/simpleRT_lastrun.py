﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2023.1.0),
    on Thu Nov 30 16:15:50 2023
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
prefs.hardware['audioLib'] = 'ptb'
prefs.hardware['audioLatencyMode'] = '3'
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)
# Store info about the experiment session
psychopyVersion = '2023.1.0'
expName = 'simpleRT'  # from the Builder filename that created this script
expInfo = {
    'Subject': '',
    'Pre(1)orPost(2)': '',
}
# --- Show participant info dialog --
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/Sub%s_%s_%s_%s' % (expInfo['Subject'], expName, expInfo['Pre(1)orPost(2)'], expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='/Users/liuq13/Library/CloudStorage/OneDrive-NationalInstitutesofHealth/KahntLabStuff/SimpleRT/simpleRT/simpleRT_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# --- Setup the Window ---
win = visual.Window(
    size=[1512, 982], fullscr=True, screen=0, 
    winType='pyglet', allowStencil=False,
    monitor='testMonitor', color='0.0000, 0.0000, 0.0000', colorSpace='rgb',
    backgroundImage='', backgroundFit='none',
    blendMode='avg', useFBO=True, 
    units='height')
win.mouseVisible = False
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess
# --- Setup input devices ---
ioConfig = {}

# Setup iohub keyboard
ioConfig['Keyboard'] = dict(use_keymap='psychopy')

ioSession = '1'
if 'session' in expInfo:
    ioSession = str(expInfo['session'])
ioServer = io.launchHubServer(window=win, **ioConfig)
eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard(backend='iohub')

# --- Initialize components for Routine "instructions" ---
instr = visual.TextStim(win=win, name='instr',
    text='In this task you will press the space bar whenever you see a red square appears. You have three seconds to respond, and please try to respond as fast as you can.\n\nIn the middle of the task, we will also ask you to rate your current feelings. \n\nPlease try your best to report your feelings at the moment when you are asked.\n\n\nPress space bar to begin the task.',
    font='Arial',
    units='height', pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
startInst = keyboard.Keyboard()
# Run 'Begin Experiment' code from code

if expInfo['Pre(1)orPost(2)']=='1':
    nblocks = 3
else:
    nblocks = 9

# --- Initialize components for Routine "Rating" ---
text_ins = visual.TextStim(win=win, name='text_ins',
    text='Press numbers 1-9 to rate your current feeling',
    font='Open Sans',
    pos=(0, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
text = visual.TextStim(win=win, name='text',
    text='',
    font='Open Sans',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
key_resp = keyboard.Keyboard()
slider = visual.Slider(win=win, name='slider',
    startValue=None, size=(1.0, 0.05), pos=(0, -0.25), units=win.units,
    labels=(1,2,3,4,5,6,7,8,9), ticks=(1,2,3,4,5,6,7,8,9), granularity=1.0,
    style='rating', styleTweaks=('labels45',), opacity=None,
    labelColor=[1.0000, 1.0000, 1.0000], markerColor=[1.0000, 1.0000, 1.0000], lineColor='White', colorSpace='rgb',
    font='Open Sans', labelHeight=0.04,
    flip=False, ori=0.0, depth=-3, readOnly=False)
text_left_end = visual.TextStim(win=win, name='text_left_end',
    text='',
    font='Open Sans',
    pos=(-0.5, -0.15), height=0.04, wrapWidth=0.3, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
text_right_end = visual.TextStim(win=win, name='text_right_end',
    text='',
    font='Open Sans',
    pos=(0.5, -0.15), height=0.04, wrapWidth=0.3, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-5.0);
text_mid = visual.TextStim(win=win, name='text_mid',
    text='Neutral',
    font='Open Sans',
    pos=(0, -0.15), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);

# --- Initialize components for Routine "timer" ---

# --- Initialize components for Routine "main" ---
response = keyboard.Keyboard()
polygon = visual.Rect(
    win=win, name='polygon',
    width=(0.3, 0.3)[0], height=(0.3, 0.3)[1],
    ori=0.0, pos=(0, 0), anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor=[1.0000, 1.0000, 1.0000], fillColor=[1.0000, 1.0000, 1.0000],
    opacity=None, depth=-1.0, interpolate=True)

# --- Initialize components for Routine "Rating" ---
text_ins = visual.TextStim(win=win, name='text_ins',
    text='Press numbers 1-9 to rate your current feeling',
    font='Open Sans',
    pos=(0, 0.2), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
text = visual.TextStim(win=win, name='text',
    text='',
    font='Open Sans',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
key_resp = keyboard.Keyboard()
slider = visual.Slider(win=win, name='slider',
    startValue=None, size=(1.0, 0.05), pos=(0, -0.25), units=win.units,
    labels=(1,2,3,4,5,6,7,8,9), ticks=(1,2,3,4,5,6,7,8,9), granularity=1.0,
    style='rating', styleTweaks=('labels45',), opacity=None,
    labelColor=[1.0000, 1.0000, 1.0000], markerColor=[1.0000, 1.0000, 1.0000], lineColor='White', colorSpace='rgb',
    font='Open Sans', labelHeight=0.04,
    flip=False, ori=0.0, depth=-3, readOnly=False)
text_left_end = visual.TextStim(win=win, name='text_left_end',
    text='',
    font='Open Sans',
    pos=(-0.5, -0.15), height=0.04, wrapWidth=0.3, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
text_right_end = visual.TextStim(win=win, name='text_right_end',
    text='',
    font='Open Sans',
    pos=(0.5, -0.15), height=0.04, wrapWidth=0.3, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-5.0);
text_mid = visual.TextStim(win=win, name='text_mid',
    text='Neutral',
    font='Open Sans',
    pos=(0, -0.15), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);

# --- Initialize components for Routine "thanks" ---
thanksText = visual.TextStim(win=win, name='thanksText',
    text='You have finished this task. Thank you!\n\nPress Space bar to exit.',
    font='Arial',
    units='height', pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
key_end = keyboard.Keyboard()

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.Clock()  # to track time remaining of each (possibly non-slip) routine 

# --- Prepare to start Routine "instructions" ---
continueRoutine = True
# update component parameters for each repeat
startInst.keys = []
startInst.rt = []
_startInst_allKeys = []
# keep track of which components have finished
instructionsComponents = [instr, startInst]
for thisComponent in instructionsComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "instructions" ---
routineForceEnded = not continueRoutine
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instr* updates
    
    # if instr is starting this frame...
    if instr.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instr.frameNStart = frameN  # exact frame index
        instr.tStart = t  # local t and not account for scr refresh
        instr.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instr, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'instr.started')
        # update status
        instr.status = STARTED
        instr.setAutoDraw(True)
    
    # if instr is active this frame...
    if instr.status == STARTED:
        # update params
        pass
    
    # *startInst* updates
    waitOnFlip = False
    
    # if startInst is starting this frame...
    if startInst.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        startInst.frameNStart = frameN  # exact frame index
        startInst.tStart = t  # local t and not account for scr refresh
        startInst.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(startInst, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'startInst.started')
        # update status
        startInst.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(startInst.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(startInst.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if startInst.status == STARTED and not waitOnFlip:
        theseKeys = startInst.getKeys(keyList=['space'], waitRelease=False)
        _startInst_allKeys.extend(theseKeys)
        if len(_startInst_allKeys):
            startInst.keys = _startInst_allKeys[-1].name  # just the last key pressed
            startInst.rt = _startInst_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instructionsComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "instructions" ---
for thisComponent in instructionsComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instructions" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
PreRatingTrials = data.TrialHandler(nReps=1.0, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('RatingConditions.xlsx'),
    seed=None, name='PreRatingTrials')
thisExp.addLoop(PreRatingTrials)  # add the loop to the experiment
thisPreRatingTrial = PreRatingTrials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisPreRatingTrial.rgb)
if thisPreRatingTrial != None:
    for paramName in thisPreRatingTrial:
        exec('{} = thisPreRatingTrial[paramName]'.format(paramName))

for thisPreRatingTrial in PreRatingTrials:
    currentLoop = PreRatingTrials
    # abbreviate parameter names if possible (e.g. rgb = thisPreRatingTrial.rgb)
    if thisPreRatingTrial != None:
        for paramName in thisPreRatingTrial:
            exec('{} = thisPreRatingTrial[paramName]'.format(paramName))
    
    # --- Prepare to start Routine "Rating" ---
    continueRoutine = True
    # update component parameters for each repeat
    text.setText(question)
    key_resp.keys = []
    key_resp.rt = []
    _key_resp_allKeys = []
    slider.reset()
    text_left_end.setText(left)
    text_right_end.setText(right)
    # keep track of which components have finished
    RatingComponents = [text_ins, text, key_resp, slider, text_left_end, text_right_end, text_mid]
    for thisComponent in RatingComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Rating" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_ins* updates
        
        # if text_ins is starting this frame...
        if text_ins.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            text_ins.frameNStart = frameN  # exact frame index
            text_ins.tStart = t  # local t and not account for scr refresh
            text_ins.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_ins, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_ins.started')
            # update status
            text_ins.status = STARTED
            text_ins.setAutoDraw(True)
        
        # if text_ins is active this frame...
        if text_ins.status == STARTED:
            # update params
            pass
        
        # *text* updates
        
        # if text is starting this frame...
        if text.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            text.frameNStart = frameN  # exact frame index
            text.tStart = t  # local t and not account for scr refresh
            text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text.started')
            # update status
            text.status = STARTED
            text.setAutoDraw(True)
        
        # if text is active this frame...
        if text.status == STARTED:
            # update params
            pass
        
        # *key_resp* updates
        waitOnFlip = False
        
        # if key_resp is starting this frame...
        if key_resp.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            key_resp.frameNStart = frameN  # exact frame index
            key_resp.tStart = t  # local t and not account for scr refresh
            key_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp.started')
            # update status
            key_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp.status == STARTED and not waitOnFlip:
            theseKeys = key_resp.getKeys(keyList=['1','2','3','4','5','6','7','8','9','num_1','num_2','num_3','num_4','num_5','num_6','num_7','num_8','num_9'], waitRelease=False)
            _key_resp_allKeys.extend(theseKeys)
            if len(_key_resp_allKeys):
                key_resp.keys = _key_resp_allKeys[-1].name  # just the last key pressed
                key_resp.rt = _key_resp_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # *slider* updates
        
        # if slider is starting this frame...
        if slider.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            slider.frameNStart = frameN  # exact frame index
            slider.tStart = t  # local t and not account for scr refresh
            slider.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(slider, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'slider.started')
            # update status
            slider.status = STARTED
            slider.setAutoDraw(True)
        
        # if slider is active this frame...
        if slider.status == STARTED:
            # update params
            pass
        
        # *text_left_end* updates
        
        # if text_left_end is starting this frame...
        if text_left_end.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            text_left_end.frameNStart = frameN  # exact frame index
            text_left_end.tStart = t  # local t and not account for scr refresh
            text_left_end.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_left_end, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_left_end.started')
            # update status
            text_left_end.status = STARTED
            text_left_end.setAutoDraw(True)
        
        # if text_left_end is active this frame...
        if text_left_end.status == STARTED:
            # update params
            pass
        
        # *text_right_end* updates
        
        # if text_right_end is starting this frame...
        if text_right_end.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            text_right_end.frameNStart = frameN  # exact frame index
            text_right_end.tStart = t  # local t and not account for scr refresh
            text_right_end.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_right_end, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_right_end.started')
            # update status
            text_right_end.status = STARTED
            text_right_end.setAutoDraw(True)
        
        # if text_right_end is active this frame...
        if text_right_end.status == STARTED:
            # update params
            pass
        
        # *text_mid* updates
        
        # if text_mid is starting this frame...
        if text_mid.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            text_mid.frameNStart = frameN  # exact frame index
            text_mid.tStart = t  # local t and not account for scr refresh
            text_mid.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_mid, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_mid.started')
            # update status
            text_mid.status = STARTED
            text_mid.setAutoDraw(True)
        
        # if text_mid is active this frame...
        if text_mid.status == STARTED:
            # update params
            pass
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in RatingComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Rating" ---
    for thisComponent in RatingComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if key_resp.keys in ['', [], None]:  # No response was made
        key_resp.keys = None
    PreRatingTrials.addData('key_resp.keys',key_resp.keys)
    if key_resp.keys != None:  # we had a response
        PreRatingTrials.addData('key_resp.rt', key_resp.rt)
    PreRatingTrials.addData('slider.rt', slider.getRT())
    # the Routine "Rating" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'PreRatingTrials'


# set up handler to look after randomisation of conditions etc
blocks = data.TrialHandler(nReps=nblocks, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=[None],
    seed=None, name='blocks')
thisExp.addLoop(blocks)  # add the loop to the experiment
thisBlock = blocks.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisBlock.rgb)
if thisBlock != None:
    for paramName in thisBlock:
        exec('{} = thisBlock[paramName]'.format(paramName))

for thisBlock in blocks:
    currentLoop = blocks
    # abbreviate parameter names if possible (e.g. rgb = thisBlock.rgb)
    if thisBlock != None:
        for paramName in thisBlock:
            exec('{} = thisBlock[paramName]'.format(paramName))
    
    # --- Prepare to start Routine "timer" ---
    continueRoutine = True
    # update component parameters for each repeat
    # Run 'Begin Routine' code from code_timer
    
    # create a countdown clock with a 300 second duration:
    timer = core.CountdownTimer(300)
    # keep track of which components have finished
    timerComponents = []
    for thisComponent in timerComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "timer" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in timerComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "timer" ---
    for thisComponent in timerComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "timer" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    mainTrials = data.TrialHandler(nReps=1, method='fullRandom', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('srttConditions.xlsx'),
        seed=None, name='mainTrials')
    thisExp.addLoop(mainTrials)  # add the loop to the experiment
    thisMainTrial = mainTrials.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisMainTrial.rgb)
    if thisMainTrial != None:
        for paramName in thisMainTrial:
            exec('{} = thisMainTrial[paramName]'.format(paramName))
    
    for thisMainTrial in mainTrials:
        currentLoop = mainTrials
        # abbreviate parameter names if possible (e.g. rgb = thisMainTrial.rgb)
        if thisMainTrial != None:
            for paramName in thisMainTrial:
                exec('{} = thisMainTrial[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "main" ---
        continueRoutine = True
        # update component parameters for each repeat
        response.keys = []
        response.rt = []
        _response_allKeys = []
        # Run 'Begin Routine' code from code_track_time
        
        # after the duration, this will become negative
        if timer.getTime() < 0: 
            mainTrials.finished = 1
        # keep track of which components have finished
        mainComponents = [response, polygon]
        for thisComponent in mainComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "main" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *response* updates
            waitOnFlip = False
            
            # if response is starting this frame...
            if response.status == NOT_STARTED and tThisFlip >= isi-frameTolerance:
                # keep track of start time/frame for later
                response.frameNStart = frameN  # exact frame index
                response.tStart = t  # local t and not account for scr refresh
                response.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(response, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'response.started')
                # update status
                response.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(response.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(response.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if response is stopping this frame...
            if response.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > response.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    response.tStop = t  # not accounting for scr refresh
                    response.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'response.stopped')
                    # update status
                    response.status = FINISHED
                    response.status = FINISHED
            if response.status == STARTED and not waitOnFlip:
                theseKeys = response.getKeys(keyList=['space'], waitRelease=False)
                _response_allKeys.extend(theseKeys)
                if len(_response_allKeys):
                    response.keys = _response_allKeys[0].name  # just the first key pressed
                    response.rt = _response_allKeys[0].rt
                    # was this correct?
                    if (response.keys == str('space')) or (response.keys == 'space'):
                        response.corr = 1
                    else:
                        response.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # *polygon* updates
            
            # if polygon is starting this frame...
            if polygon.status == NOT_STARTED and tThisFlip >= isi-frameTolerance:
                # keep track of start time/frame for later
                polygon.frameNStart = frameN  # exact frame index
                polygon.tStart = t  # local t and not account for scr refresh
                polygon.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(polygon, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'polygon.started')
                # update status
                polygon.status = STARTED
                polygon.setAutoDraw(True)
            
            # if polygon is active this frame...
            if polygon.status == STARTED:
                # update params
                pass
            
            # if polygon is stopping this frame...
            if polygon.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > polygon.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    polygon.tStop = t  # not accounting for scr refresh
                    polygon.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'polygon.stopped')
                    # update status
                    polygon.status = FINISHED
                    polygon.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in mainComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "main" ---
        for thisComponent in mainComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # check responses
        if response.keys in ['', [], None]:  # No response was made
            response.keys = None
            # was no response the correct answer?!
            if str('space').lower() == 'none':
               response.corr = 1;  # correct non-response
            else:
               response.corr = 0;  # failed to respond (incorrectly)
        # store data for mainTrials (TrialHandler)
        mainTrials.addData('response.keys',response.keys)
        mainTrials.addData('response.corr', response.corr)
        if response.keys != None:  # we had a response
            mainTrials.addData('response.rt', response.rt)
        # the Routine "main" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 1 repeats of 'mainTrials'
    
    
    # set up handler to look after randomisation of conditions etc
    RatingTrials = data.TrialHandler(nReps=1.0, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('RatingConditions.xlsx'),
        seed=None, name='RatingTrials')
    thisExp.addLoop(RatingTrials)  # add the loop to the experiment
    thisRatingTrial = RatingTrials.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisRatingTrial.rgb)
    if thisRatingTrial != None:
        for paramName in thisRatingTrial:
            exec('{} = thisRatingTrial[paramName]'.format(paramName))
    
    for thisRatingTrial in RatingTrials:
        currentLoop = RatingTrials
        # abbreviate parameter names if possible (e.g. rgb = thisRatingTrial.rgb)
        if thisRatingTrial != None:
            for paramName in thisRatingTrial:
                exec('{} = thisRatingTrial[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "Rating" ---
        continueRoutine = True
        # update component parameters for each repeat
        text.setText(question)
        key_resp.keys = []
        key_resp.rt = []
        _key_resp_allKeys = []
        slider.reset()
        text_left_end.setText(left)
        text_right_end.setText(right)
        # keep track of which components have finished
        RatingComponents = [text_ins, text, key_resp, slider, text_left_end, text_right_end, text_mid]
        for thisComponent in RatingComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Rating" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_ins* updates
            
            # if text_ins is starting this frame...
            if text_ins.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                text_ins.frameNStart = frameN  # exact frame index
                text_ins.tStart = t  # local t and not account for scr refresh
                text_ins.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_ins, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_ins.started')
                # update status
                text_ins.status = STARTED
                text_ins.setAutoDraw(True)
            
            # if text_ins is active this frame...
            if text_ins.status == STARTED:
                # update params
                pass
            
            # *text* updates
            
            # if text is starting this frame...
            if text.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                text.frameNStart = frameN  # exact frame index
                text.tStart = t  # local t and not account for scr refresh
                text.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text.started')
                # update status
                text.status = STARTED
                text.setAutoDraw(True)
            
            # if text is active this frame...
            if text.status == STARTED:
                # update params
                pass
            
            # *key_resp* updates
            waitOnFlip = False
            
            # if key_resp is starting this frame...
            if key_resp.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                key_resp.frameNStart = frameN  # exact frame index
                key_resp.tStart = t  # local t and not account for scr refresh
                key_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp.started')
                # update status
                key_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp.status == STARTED and not waitOnFlip:
                theseKeys = key_resp.getKeys(keyList=['1','2','3','4','5','6','7','8','9','num_1','num_2','num_3','num_4','num_5','num_6','num_7','num_8','num_9'], waitRelease=False)
                _key_resp_allKeys.extend(theseKeys)
                if len(_key_resp_allKeys):
                    key_resp.keys = _key_resp_allKeys[-1].name  # just the last key pressed
                    key_resp.rt = _key_resp_allKeys[-1].rt
                    # a response ends the routine
                    continueRoutine = False
            
            # *slider* updates
            
            # if slider is starting this frame...
            if slider.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                slider.frameNStart = frameN  # exact frame index
                slider.tStart = t  # local t and not account for scr refresh
                slider.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(slider, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'slider.started')
                # update status
                slider.status = STARTED
                slider.setAutoDraw(True)
            
            # if slider is active this frame...
            if slider.status == STARTED:
                # update params
                pass
            
            # *text_left_end* updates
            
            # if text_left_end is starting this frame...
            if text_left_end.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                text_left_end.frameNStart = frameN  # exact frame index
                text_left_end.tStart = t  # local t and not account for scr refresh
                text_left_end.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_left_end, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_left_end.started')
                # update status
                text_left_end.status = STARTED
                text_left_end.setAutoDraw(True)
            
            # if text_left_end is active this frame...
            if text_left_end.status == STARTED:
                # update params
                pass
            
            # *text_right_end* updates
            
            # if text_right_end is starting this frame...
            if text_right_end.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                text_right_end.frameNStart = frameN  # exact frame index
                text_right_end.tStart = t  # local t and not account for scr refresh
                text_right_end.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_right_end, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_right_end.started')
                # update status
                text_right_end.status = STARTED
                text_right_end.setAutoDraw(True)
            
            # if text_right_end is active this frame...
            if text_right_end.status == STARTED:
                # update params
                pass
            
            # *text_mid* updates
            
            # if text_mid is starting this frame...
            if text_mid.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                text_mid.frameNStart = frameN  # exact frame index
                text_mid.tStart = t  # local t and not account for scr refresh
                text_mid.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_mid, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_mid.started')
                # update status
                text_mid.status = STARTED
                text_mid.setAutoDraw(True)
            
            # if text_mid is active this frame...
            if text_mid.status == STARTED:
                # update params
                pass
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RatingComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Rating" ---
        for thisComponent in RatingComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # check responses
        if key_resp.keys in ['', [], None]:  # No response was made
            key_resp.keys = None
        RatingTrials.addData('key_resp.keys',key_resp.keys)
        if key_resp.keys != None:  # we had a response
            RatingTrials.addData('key_resp.rt', key_resp.rt)
        RatingTrials.addData('slider.rt', slider.getRT())
        # the Routine "Rating" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'RatingTrials'
    
# completed nblocks repeats of 'blocks'


# --- Prepare to start Routine "thanks" ---
continueRoutine = True
# update component parameters for each repeat
key_end.keys = []
key_end.rt = []
_key_end_allKeys = []
# keep track of which components have finished
thanksComponents = [thanksText, key_end]
for thisComponent in thanksComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "thanks" ---
routineForceEnded = not continueRoutine
while continueRoutine and routineTimer.getTime() < 3.0:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *thanksText* updates
    
    # if thanksText is starting this frame...
    if thanksText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        thanksText.frameNStart = frameN  # exact frame index
        thanksText.tStart = t  # local t and not account for scr refresh
        thanksText.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(thanksText, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'thanksText.started')
        # update status
        thanksText.status = STARTED
        thanksText.setAutoDraw(True)
    
    # if thanksText is active this frame...
    if thanksText.status == STARTED:
        # update params
        pass
    
    # if thanksText is stopping this frame...
    if thanksText.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > thanksText.tStartRefresh + 3-frameTolerance:
            # keep track of stop time/frame for later
            thanksText.tStop = t  # not accounting for scr refresh
            thanksText.frameNStop = frameN  # exact frame index
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'thanksText.stopped')
            # update status
            thanksText.status = FINISHED
            thanksText.setAutoDraw(False)
    
    # *key_end* updates
    waitOnFlip = False
    
    # if key_end is starting this frame...
    if key_end.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_end.frameNStart = frameN  # exact frame index
        key_end.tStart = t  # local t and not account for scr refresh
        key_end.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_end, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'key_end.started')
        # update status
        key_end.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_end.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_end.clearEvents, eventType='keyboard')  # clear events on next screen flip
    
    # if key_end is stopping this frame...
    if key_end.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > key_end.tStartRefresh + 3-frameTolerance:
            # keep track of stop time/frame for later
            key_end.tStop = t  # not accounting for scr refresh
            key_end.frameNStop = frameN  # exact frame index
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_end.stopped')
            # update status
            key_end.status = FINISHED
            key_end.status = FINISHED
    if key_end.status == STARTED and not waitOnFlip:
        theseKeys = key_end.getKeys(keyList=['space'], waitRelease=False)
        _key_end_allKeys.extend(theseKeys)
        if len(_key_end_allKeys):
            key_end.keys = _key_end_allKeys[-1].name  # just the last key pressed
            key_end.rt = _key_end_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in thanksComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "thanks" ---
for thisComponent in thanksComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_end.keys in ['', [], None]:  # No response was made
    key_end.keys = None
thisExp.addData('key_end.keys',key_end.keys)
if key_end.keys != None:  # we had a response
    thisExp.addData('key_end.rt', key_end.rt)
thisExp.nextEntry()
# using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
if routineForceEnded:
    routineTimer.reset()
else:
    routineTimer.addTime(-3.000000)

# --- End experiment ---
# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
if eyetracker:
    eyetracker.setConnectionState(False)
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()

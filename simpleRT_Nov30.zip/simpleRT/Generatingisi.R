
library(xlsx)
df = data.frame(isi = runif(100,1,10))
write.xlsx(df,file = 'srttConditions.xlsx',row.names = F)
